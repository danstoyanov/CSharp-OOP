﻿namespace P04_Border_Control.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
