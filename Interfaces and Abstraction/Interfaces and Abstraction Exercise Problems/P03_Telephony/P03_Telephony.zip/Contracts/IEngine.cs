﻿namespace P03_Telephony.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
