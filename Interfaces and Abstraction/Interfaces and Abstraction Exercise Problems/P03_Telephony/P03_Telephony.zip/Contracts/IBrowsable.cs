﻿namespace P03_Telephony.Contracts
{
    public interface IBrowsable
    {
        string Browse(string url);
    }
}
