﻿namespace Telephony.Core
{
    public interface IEngine
    {
        void Run();
    }
}
