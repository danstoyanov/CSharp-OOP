﻿using P04_Border_Control.Core;
using System;

namespace P04_Border_Control
{
    class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
