﻿using System;

namespace P05_Birthday_Celebrations.Contracts
{
    public interface IPet
    {
        public string Name { get; }
    }
}
