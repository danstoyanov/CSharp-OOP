﻿namespace P04_Border_Control.Contracts
{
    public interface IInhabitants
    {
        public string Id { get; }
    }
}
