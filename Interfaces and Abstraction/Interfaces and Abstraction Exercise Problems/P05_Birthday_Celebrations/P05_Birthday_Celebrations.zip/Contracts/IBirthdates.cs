﻿namespace P05_Birthday_Celebrations.Contracts
{
    public interface IBirthdates
    {
        public string Birthdate { get; }
    }
}
