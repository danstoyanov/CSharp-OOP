﻿namespace P04_Border_Control.Contracts
{
    public interface IRobot
    {
        public string Model { get; }
        public string Id { get; }
    }
}
