﻿using System;

namespace P04_Border_Control.Contracts
{
    public interface ICitizen
    {
        public string Name { get; }
        public string Age { get; }
        public string Id { get; }
    }
}
