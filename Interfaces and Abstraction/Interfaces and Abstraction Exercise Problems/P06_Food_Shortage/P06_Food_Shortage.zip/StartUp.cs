﻿using System;

using P06_Food_Shortage.Core;

namespace P06_Food_Shortage
{
    public class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
