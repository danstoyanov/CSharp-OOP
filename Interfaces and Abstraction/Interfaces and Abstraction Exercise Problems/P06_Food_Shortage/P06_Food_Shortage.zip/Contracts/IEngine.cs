﻿namespace P06_Food_Shortage.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
