﻿namespace P06_Food_Shortage.Contracts
{
    public interface IRebel
    {
        public string Name { get; }
        public string Age { get; }
        public string Group { get; }
    }
}
