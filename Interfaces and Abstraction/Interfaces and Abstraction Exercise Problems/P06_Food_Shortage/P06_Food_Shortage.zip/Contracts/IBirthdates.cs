﻿namespace P06_Food_Shortage.Contracts
{
    public interface IBirthdates
    {
        public string Birthdate { get; }
    }
}
