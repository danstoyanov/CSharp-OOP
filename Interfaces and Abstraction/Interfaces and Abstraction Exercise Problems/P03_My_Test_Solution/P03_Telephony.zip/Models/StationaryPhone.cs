﻿using System.Linq;

using P03_My_Test_Solution.Contracts;
using P03_My_Test_Solution.Exceptions;

namespace P03_My_Test_Solution.Models
{
    public class StationaryPhone : ICallable
    {
        public StationaryPhone()
        {

        }

        public string Call(string number)
        {
            if (! number.All(c => char.IsDigit(c)))
            {
                throw new InvalidNumberException();
            }

            return $"Dialing... {number}";
        }
    }
}
