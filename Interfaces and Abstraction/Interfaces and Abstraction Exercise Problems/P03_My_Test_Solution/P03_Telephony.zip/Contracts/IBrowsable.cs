﻿namespace P03_My_Test_Solution.Contracts
{
    public interface IBrowsable
    {
        string Browse(string url);
    }
}
