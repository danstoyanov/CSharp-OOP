﻿namespace P03_My_Test_Solution.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
