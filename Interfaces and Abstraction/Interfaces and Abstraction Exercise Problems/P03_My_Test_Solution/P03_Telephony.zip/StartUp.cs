﻿using P03_My_Test_Solution.Core;

namespace P03_My_Test_Solution
{
    public class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
