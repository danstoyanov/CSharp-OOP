﻿namespace P07_Military_Elite.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
