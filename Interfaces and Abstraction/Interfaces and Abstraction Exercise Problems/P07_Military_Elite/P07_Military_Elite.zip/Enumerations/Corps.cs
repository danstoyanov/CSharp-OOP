﻿namespace P07_Military_Elite.Contracts
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
