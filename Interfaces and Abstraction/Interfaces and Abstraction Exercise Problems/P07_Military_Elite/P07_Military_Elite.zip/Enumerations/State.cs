﻿namespace P07_Military_Elite.Core
{
    public enum State
    {
        inProgress,
        Finished
    }
}
