﻿using System;

using P07_Military_Elite.Core.IO.Contracts;

namespace P07_Military_Elite.IO
{
    public class ConsoleWriter : IWriter
    {
        public void Write(string text)
        {
            Console.Write(text);
        }

        public void WriteLine(string text)
        {
            Console.WriteLine(text);
        }
    }
}
