﻿namespace P07_Military_Elite.Core.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
