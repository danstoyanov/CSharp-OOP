﻿namespace PersonInfo
{
    public class PersonInfo
    {

    }
}
