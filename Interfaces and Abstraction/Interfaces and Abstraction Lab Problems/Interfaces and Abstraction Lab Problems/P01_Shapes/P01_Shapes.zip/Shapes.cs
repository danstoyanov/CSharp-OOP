﻿namespace Shapes
{
    public class Shapes
    {
        public int Radius { get; set; }
    }
}
