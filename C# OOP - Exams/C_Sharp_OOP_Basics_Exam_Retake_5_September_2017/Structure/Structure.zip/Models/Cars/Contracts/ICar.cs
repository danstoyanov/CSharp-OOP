﻿namespace Structure.Models.Cars.Contracts
{
    public interface ICar
    {
        int Hp { get; }
        double FuelAmount { get; }
    }
}
