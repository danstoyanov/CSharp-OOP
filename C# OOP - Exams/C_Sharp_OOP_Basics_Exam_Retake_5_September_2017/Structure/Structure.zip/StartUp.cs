﻿using System;

namespace Structure
{
    public class StartUp
    {
        static void Main()
        {

        }
    }
}
