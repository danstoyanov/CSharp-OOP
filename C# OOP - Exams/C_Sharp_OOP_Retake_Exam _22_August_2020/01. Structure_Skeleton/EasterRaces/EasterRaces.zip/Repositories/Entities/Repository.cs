﻿using System.Linq;
using System.Collections.Generic;

using EasterRaces.Repositories.Contracts;

namespace EasterRaces.Repositories.Entities
{
    public abstract class Repository<T> : IRepository<T>
    {
        private readonly List<T> entities;

        public Repository()
        {
            this.entities = new List<T>();
        }

        public void Add(T model)
        {
            this.entities.Add(model);
        }

        public IReadOnlyCollection<T> GetAll()
        {
            return this.entities;
        }

        public T GetByName(string name)
        {
            var current = this.entities.Where(e => e.GetType().Name == name);

            return (T)current;
        }

        public bool Remove(T model)
        {
            return this.entities.Remove(model);
        }
    }
}
