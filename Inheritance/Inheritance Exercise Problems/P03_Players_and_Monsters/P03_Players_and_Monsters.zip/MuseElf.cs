﻿namespace PlayersAndMonsters
{
    public class MuseElf : Elf
    {
        public MuseElf(string username, int level)
        {
            this.Username = username;
            this.Level = level;
        }
    }
}
