﻿namespace PlayersAndMonsters
{
    using System;

    public class SoulMaster : Wizard
    {

    }
}
