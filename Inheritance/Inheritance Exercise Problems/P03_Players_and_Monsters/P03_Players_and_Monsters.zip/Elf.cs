﻿namespace PlayersAndMonsters
{
    using System;

    public class Elf : Hero
    {

    }
}
