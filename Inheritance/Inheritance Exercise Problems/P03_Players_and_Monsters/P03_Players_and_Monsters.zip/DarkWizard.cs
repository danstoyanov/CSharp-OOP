﻿namespace PlayersAndMonsters
{
    using System;

    public class DarkWizard : Wizard
    {

    }
}
