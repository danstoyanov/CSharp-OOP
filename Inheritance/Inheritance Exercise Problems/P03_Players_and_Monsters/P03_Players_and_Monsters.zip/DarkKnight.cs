﻿namespace PlayersAndMonsters
{
    using System;

    public class DarkKnight : Knight
    {

    }
}
