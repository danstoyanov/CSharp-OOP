﻿namespace PlayersAndMonsters
{
    using System;

    public class Wizard : Hero
    {

    }
}
