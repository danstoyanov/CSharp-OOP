﻿namespace PlayersAndMonsters
{
    using System;

    public class BladeKnight : Knight
    {

    }
}
