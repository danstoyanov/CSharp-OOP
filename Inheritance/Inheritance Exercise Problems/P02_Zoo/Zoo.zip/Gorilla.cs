﻿namespace Zoo
{
    using System;

    public class Gorilla : Mammal
    {

    }
}
