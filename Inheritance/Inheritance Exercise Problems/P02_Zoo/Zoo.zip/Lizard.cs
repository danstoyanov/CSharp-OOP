﻿namespace Zoo
{
    using System;

    public class Lizard : Reptile
    {

    }
}
