﻿namespace Zoo
{
    using System;

    public class Animal
    {

    }
}
