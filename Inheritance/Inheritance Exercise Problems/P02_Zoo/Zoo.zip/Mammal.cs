﻿namespace Zoo
{
    using System;

    public class Mammal : Animal
    {

    }
}
