﻿namespace Zoo
{
    using System;

    public class Bear : Mammal
    {

    }
}
