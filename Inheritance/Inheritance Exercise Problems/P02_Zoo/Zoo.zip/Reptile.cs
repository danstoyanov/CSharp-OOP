﻿namespace Zoo
{
    using System;

    public class Reptile : Animal
    {

    }
}
