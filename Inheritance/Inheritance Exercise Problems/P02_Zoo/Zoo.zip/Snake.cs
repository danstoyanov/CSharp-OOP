﻿namespace Zoo
{
using System;

    public class Snake : Reptile
    {

    }
}
