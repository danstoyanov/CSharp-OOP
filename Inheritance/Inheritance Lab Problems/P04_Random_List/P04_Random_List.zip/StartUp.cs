﻿namespace CustomRandomList
{
    using System;
    using System.Security.Cryptography.X509Certificates;

    public class StartUp
    {
        static void Main()
        {
            
        }
    }
}
