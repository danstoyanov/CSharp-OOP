﻿namespace Farm
{
    public class Cat : Animal
    {
        public void Meow()
        {
            System.Console.WriteLine("meowing...");
        }
    }
}
