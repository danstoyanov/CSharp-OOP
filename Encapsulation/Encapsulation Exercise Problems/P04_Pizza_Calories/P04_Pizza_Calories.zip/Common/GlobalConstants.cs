﻿namespace P04_Pizza_Calories.Common
{
    public class GlobalConstants
    {
        internal const int BASE_CALORIES_PER_GRAM = 2;
    }
}
