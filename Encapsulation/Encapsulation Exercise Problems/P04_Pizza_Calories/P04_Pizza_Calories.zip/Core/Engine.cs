﻿namespace P04_Pizza_Calories.Core
{
    public class Engine
    {
        public Engine()
        {

        }

        public void Run()
        {

        }
    }
}
