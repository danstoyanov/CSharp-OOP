using NUnit.Framework;

namespace Tests
{
    [TestFixture]
    public class DatabaseTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Capacity_Test_Are_Equal_To_Sixteen()
        {
            // Arrange
            var array = new int[16];
            var data = new Database(array);

            // Act
            var arrSize = array.Length;

            // Assert
            Assert.AreEqual(data.Count, arrSize);
        }
    }
}