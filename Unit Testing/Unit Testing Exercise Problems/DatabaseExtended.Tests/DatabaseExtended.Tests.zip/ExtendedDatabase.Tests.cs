using ExtendedDatabase;
using NUnit.Framework;

namespace Tests
{
    public class ExtendedDatabaseTests
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void User_With_Same_Username_Exception()
        {
            //Arrange
            Person TEST_PERSON = new Person(54932233, "Mincho");

            long firstID = 54932233;
            string firstName = "Mincho";

            long secondID = 323132158;
            string secondName = "Ivan";

            var firstPerson = new Person(firstID, firstName);
            var secondPerson = new Person(secondID, secondName);

            var data = new ExtendedDatabase.ExtendedDatabase(firstPerson, secondPerson);

            //Act

            //Assert
            Assert.That(() => data.Add(TEST_PERSON),
                Throws
                .InvalidOperationException
                .With
                .Message
                .EqualTo("There is already user with this username!"));

        }
    }
}