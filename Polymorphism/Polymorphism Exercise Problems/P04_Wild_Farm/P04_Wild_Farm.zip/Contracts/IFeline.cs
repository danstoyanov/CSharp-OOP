﻿namespace P04_Wild_Farm.Contracts
{
    public interface IFeline
    {
        public string Breed { get; }
    }
}
