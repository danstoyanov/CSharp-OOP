﻿namespace P04_Wild_Farm.Contracts
{
    public interface IFood
    {
        public int Quantity { get; }
    }
}
