﻿namespace P04_Wild_Farm.Contracts
{
    public interface IMammal
    {
        public string LivingRegion { get; }
    }
}
