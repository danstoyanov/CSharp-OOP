﻿namespace P04_Wild_Farm.Contracts
{
    public interface IBird
    {
        public double WingSize { get; }
    }
}
