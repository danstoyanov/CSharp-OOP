﻿namespace P01_Exercise_Lecture_Variant.Models.Contracts
{
    public interface IRefuelable
    {
        void Refuel(double amount);
    }
}
