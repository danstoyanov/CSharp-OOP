﻿using System;

using P01_Exercise_Lecture_Variant.Core;

namespace P01_Exercise_Lecture_Variant
{
    public class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
