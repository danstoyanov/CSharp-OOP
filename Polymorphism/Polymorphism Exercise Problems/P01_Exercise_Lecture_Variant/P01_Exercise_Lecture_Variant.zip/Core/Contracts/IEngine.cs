﻿namespace P01_Exercise_Lecture_Variant.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
