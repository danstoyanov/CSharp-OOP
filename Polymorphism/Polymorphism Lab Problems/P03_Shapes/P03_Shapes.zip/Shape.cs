﻿namespace Shapes
{
    public class Shape
    {
        public virtual string Draw()
        {
            return "Drawing ";
        }
    }
}
