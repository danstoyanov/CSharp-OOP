﻿namespace Stealer
{
    public interface ISpy
    {
        string StealFieldInfo(string investigate, params string[] arr);
    }
}
